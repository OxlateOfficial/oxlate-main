# OXLATE INTERNAL BRAIN

## Project Summary
Full rebuild of the Oxlate website based on master plan documentation, storyboard (`IMG_20260910_102011.jpg`), and concept reference (`HeroRoughIdea.png`). The site is an architectural editorial technology platform with an oversized dominant X, multi-stage scroll construction, and disciplined monochrome/ivory/bronze palette.

## Current Objective
Phase 0 Discovery complete -> Moving through Foundation, Hero Visual Engine & Motion, Core Sections, UI Primitives, Assets, SEO, and QA.

## Architecture
- Framework: Next.js 16.3 (Turbopack, App Router, React 19)
- Styling: Tailwind CSS v4, CSS custom properties for palette and architectural layers
- Fonts: Geist Sans, Geist Mono, Orbitron
- Animation: Framer Motion (useScroll, useTransform, Spring easing), Lenis smooth scrolling
- Feature Structure: `features/` or `components/features/home/` with dedicated feature submodules

## Global Non-Negotiable Rules
1. THE TRUTH RULE: No fake testimonials, metrics, clients, or awards. Independent work marked explicitly as "Independent Project" or "Founding Developer's Work".
2. PALETTE LOCKDOWN: Warm Ivory (#F5F2EC), Deep Black (#111111), Graphite (#292929), Pale Stone (#D9D4CC), Soft Cream (#ECE8E1), Pure Parchment (#FAF8F5), Restrained Bronze (#A87445) strictly at 2-5% UI area. No blue/purple/neon gradients.
3. GIANT X/LOGO IS CENTRAL: Oversized architectural monument covering viewport as designed poster. Never shrink to small centered logo.
4. HERO SCROLL CHOREOGRAPHY: State 1 (Poster landing) -> State 2 (Translation & construction) -> State 3 (Monolithic center lock & surroundings assemble) -> State 4 (Unpins cleanly into Section 02).
5. MICRO-ELEMENTS & CONSTRUCTION: Every line, tick (+), number, coordinate tag, and rail has an intentional structural purpose and coordinated micro-motion.
6. MACHINE READABLE SEO: Single semantic H1, plain text in HTML, structured JSON-LD schemas.
7. ACCESSIBILITY: Full prefers-reduced-motion support, keyboard navigable, zero scroll-jacking on mobile.

# OXLATE ARCHITECTURAL & DESIGN DECISIONS

## DECISION-001: Font System Integration
- **Decision**: Activate `Orbitron` Google Font via `next/font/google` in `app/layout.tsx` with CSS variable `--font-orbitron`. Restrict usage strictly to brand wordmark, section numbers, and technical coordinate tags. Use `Geist Sans` for headlines and body text, and `Geist Mono` for metadata chips.
- **Reason**: Aligns with master typography specification `02-TYPOGRAPHY.md` and user directives. Prevents font substitution.
- **Affected Area**: `app/layout.tsx`, `app/globals.css`, UI typography.

## DECISION-002: Giant Architectural X Dimensions and Hero Composition
- **Decision**: Render the Giant X with authentic scale—filling 85vh to 95vh height and bleeding off the right viewport edge in Stage 1, then translating to center in Stage 2/3, with structural geometry, "Architecture Discipline" angled arm tag, and diagonal service band running across.
- **Reason**: The reference sketch `HeroRoughIdea.png` and storyboard `IMG_20260910_102011.jpg` mandate a massive architectural presence, never a small centered logo.
- **Affected Area**: `features/home/hero/` components.

## DECISION-003: Architectural Layer System (L0–L8)
- **Decision**: Standardize z-index tokens:
  - L0: Base Canvas Atmosphere (`z-0`)
  - L1: Global Architectural Grid & CAD linework (`z-[1]`)
  - L2: Brand Structural Geometry & Giant X (`z-10`)
  - L3: Decorative Micro-elements & Diagonal Datum Beams (`z-20`)
  - L4: Elevated Surfaces & Card Panels (`z-30`)
  - L5: Primary Semantic Content & Headlines (`z-40`)
  - L6: Motion Overlays & Threshold transitions (`z-45`)
  - L7: Persistent Navigation & Orientation Dial (`z-50`)
- **Reason**: Prevents occlusion and maintains consistent z-index hierarchy across viewports.
- **Affected Area**: All sections and shared UI primitives.

## DECISION-004: Mobile Composition & Touch Ergonomics
- **Decision**: On viewports `< 768px`, disable scroll-pinning sticky traps. Render an intentional vertical monument layout: top architectural header, vertical monument hero with clean logo mark, H1, subtitle, full-width bronze CTA, and floating status ticker pill (`01 / 06 • INTRO`).
- **Reason**: Adheres to non-negotiable rule of Zero Scroll-Jacking on mobile devices.
- **Affected Area**: Hero mobile, navigation, section layouts.

## DECISION-005: Purge of Unused Legacy Components
- **Decision**: Delete orphaned components in `components/ui/` (`kinetic-x/`, `kinetic-x-portal.tsx`, `laptop-3d.tsx`, `expandable-staircase.tsx`, `portfolio-pillars.tsx`, `device-mockup.tsx`, etc.) and duplicate `features/home/nav/nav.constants.ts`.
- **Reason**: Eliminates dead code, reduces bundle weight, and enforces feature-based architecture.
- **Affected Area**: `components/ui/`, `features/`.

## DECISION-006: No-Card Hero Principle (MANDATORY INVARIANT)
- **Decision**: The homepage hero does NOT use conventional card UI. Information is represented through composition, typography, annotations, rails, architectural fields, and structural relationships. A rectangular boundary may exist only when it has a genuine architectural or editorial purpose. Generic cards, floating panels, dashboard panels, feature cards, and SaaS-style containers are strictly prohibited in the hero.
- **Reason**: Conventional cards turn an architectural drawing into a standard SaaS landing page. Information must be embedded into the structure itself, sitting directly on the canvas with fine datum lines, registration crosses, and typographic hierarchy.
- **Affected Area**: `components/features/home/hero/`, master layout.

# OXLATE QA TRACKER

| Defect ID | Description | Severity | Status | Verification Plan |
|:---|:---|:---|:---|:---|
| QA-01 | Orbitron font missing from layout/font loaders | High | RESOLVED | Configured in `app/layout.tsx` and `globals.css` |
| QA-02 | Giant X shrunk to 60vh center box instead of full architectural monument | Critical | RESOLVED | Monument reconstructed at 88vh-98vh scale with 42° strut plate |
| QA-03 | Hero surroundings lack independent construction animations | High | RESOLVED | Independent drawing for axes, diagonal struts, ticks, and service rail |
| QA-04 | Orphaned UI components in codebase (`components/ui/kinetic-x/*`, etc.) | Medium | RESOLVED | Deleted; cleaned components/ui to button and smooth-scroll |
| QA-05 | Semantic HTML structure & SEO metadata audit | Medium | RESOLVED | Strictly single H1, JSON-LD Organization/WebSite/Services, sitemap.ts, robots.ts |
| QA-06 | Reduced-motion fallback verification | High | RESOLVED | Instant static layout via useReducedMotion hook & CSS fallback |
| QA-07 | Mobile touch ergonomics | High | RESOLVED | Vertical monument layout with zero sticky scroll traps on mobile |
